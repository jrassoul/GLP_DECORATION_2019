package decoration;

public class Porte extends NonMobile{
	
	public Porte(float length, float width, float height) {
		super(length, width, height);
	}
}
