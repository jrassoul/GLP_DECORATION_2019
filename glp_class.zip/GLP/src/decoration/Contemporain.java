package decoration;

public class Contemporain extends Style{

}
