package decoration;

public class Sol extends NonMobile{

	public Sol(float length, float width, float height) {
		super(length, width, height);
		}

}
