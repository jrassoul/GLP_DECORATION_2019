package decoration;

public class Salon extends Piece {

	public Salon(float length, float width, Appartement a) {
		super(length, width, a);
	}
	
}
