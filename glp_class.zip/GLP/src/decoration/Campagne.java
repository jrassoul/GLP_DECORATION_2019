package decoration;

public class Campagne extends Style {

}
