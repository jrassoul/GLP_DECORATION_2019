package decoration;

public class SalleDeBain extends Piece {

	public SalleDeBain(float length, float width, Appartement a) {
		super(length, width, a);
	}

}
