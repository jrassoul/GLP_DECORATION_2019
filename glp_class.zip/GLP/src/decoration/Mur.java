package decoration;

public class Mur extends NonMobile{

	public Mur(float length, float width, float height) {
		super(length, width, height);
	}

}
