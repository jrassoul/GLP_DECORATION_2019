package decoration;

public abstract class ObjetSol extends Mobile{

	public ObjetSol(float length, float width, float height) {
		super(length, width, height);
	}

}
