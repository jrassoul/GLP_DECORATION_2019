package decoration;

public class Retro extends Style {

}
