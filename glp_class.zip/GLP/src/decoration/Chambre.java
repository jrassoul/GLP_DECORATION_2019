package decoration;

public class Chambre extends Piece {

	public Chambre(float length, float width, Appartement a) {
		super(length, width, a);
	}

}
