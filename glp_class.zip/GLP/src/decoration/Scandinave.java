package decoration;

public class Scandinave extends Style {

}
