package decoration;

public abstract class ObjetMur extends Mobile{

	public ObjetMur(float length, float width, float height) {
		super(length, width, height);
	}

}
