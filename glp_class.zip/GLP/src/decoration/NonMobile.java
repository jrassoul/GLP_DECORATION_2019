package decoration;

public abstract class NonMobile extends ElementDecoration{

	public NonMobile(float length, float width, float height) {
		super(length, width, height);
	}
	

}
