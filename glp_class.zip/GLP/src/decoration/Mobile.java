package decoration;

public abstract class Mobile extends ElementDecoration{

	public Mobile(float length, float width, float height) {
		super(length, width, height);
	}
}
