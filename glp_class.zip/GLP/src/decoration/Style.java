package decoration;

public abstract class Style {

}
