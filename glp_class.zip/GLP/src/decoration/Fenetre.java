package decoration;

public class Fenetre extends NonMobile{

	public Fenetre(float length, float width, float height) {
		super(length, width, height);
	}
}
