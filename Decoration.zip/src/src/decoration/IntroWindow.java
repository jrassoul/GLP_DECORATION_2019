package decoration;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class IntroWindow extends JFrame implements ActionListener{
	
	/**
	 * fenêtre d'accueil
	 */
	private static final long serialVersionUID = 7460708311443654131L;

	private JPanel container = new JPanel();
	
	// première ligne
	private JPanel l1 = new JPanel();
	private JLabel intro = new JLabel("Bienvenue dans l'application Décoration !");
	
	// trois lignes, une pour chaque pièce, l'utilisateur entre les dimensions
	private JPanel l2 = new JPanel();
	private JLabel bed1 = new JLabel("Veuillez entrer les dimensions de la chambre : longueur :");
	private JTextField bedl = new JTextField();
	private JLabel bed2 = new JLabel("largeur :");
	private JTextField bedw = new JTextField();

	private JPanel l3 = new JPanel();
	private JLabel liv1 = new JLabel("Veuillez entrer les dimensions du salon : longueur :");
	private JTextField livl = new JTextField();
	private JLabel liv2 = new JLabel("largeur :");
	private JTextField livw = new JTextField();
	
	private JPanel l4 = new JPanel();
	private JLabel bat1 = new JLabel("Veuillez entrer les dimensions de la salle de bain : longueur :");
	private JTextField batl = new JTextField();
	private JLabel bat2 = new JLabel("largeur :");
	private JTextField batw = new JTextField();
	
	private JPanel l5 = new JPanel();
	private JButton finish = new JButton("Terminer");
	
	public IntroWindow() {
		
		// définit la taille de la fenêtre, son action lors de sa fermeture
		this.setTitle("Bienvenue");
		this.setSize(700, 300);
		this.setLocationRelativeTo(null);
		this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		this.setResizable(false);
		
		//mise en place de chacune des lignes
		
		this.l1.setLayout(new BoxLayout(this.l1, BoxLayout.LINE_AXIS));
		this.l1.add(this.intro);
		
		this.l2.setLayout(new BoxLayout(this.l2, BoxLayout.LINE_AXIS));
		this.l2.add(this.bed1);
		this.l2.add(this.bedl);
		this.l2.add(this.bed2);
		this.l2.add(this.bedw);

		this.l3.setLayout(new BoxLayout(this.l3, BoxLayout.LINE_AXIS));
		this.l3.add(this.liv1);
		this.l3.add(this.livl);
		this.l3.add(this.liv2);
		this.l3.add(this.livw);
		
		this.l4.setLayout(new BoxLayout(this.l4, BoxLayout.LINE_AXIS));
		this.l4.add(this.bat1);
		this.l4.add(this.batl);
		this.l4.add(this.bat2);
		this.l4.add(this.batw);
		
		this.l5.add(this.finish);
		
		this.finish.addActionListener(this);
		
		// place chaque ligne dans le bon odre
		this.container.setLayout(new BoxLayout(container, BoxLayout.PAGE_AXIS));
		this.container.add(l1);
		this.container.add(l2);
		this.container.add(l3);
		this.container.add(l4);
		this.container.add(l5);
		
		this.getContentPane().add(container);
		this.setVisible(true);
	}
	
	public void actionPerformed(ActionEvent arg0) {
		
		// action du bouton Finish
		// récupère les valeurs entrées par l'utilisateur et crée les objets correspondants
		
		Bedroom chambre = new Bedroom(Integer.parseInt(this.bedl.getText()), Integer.parseInt(this.bedw.getText()));
		LivingRoom salon = new LivingRoom(Integer.parseInt(this.livl.getText()), Integer.parseInt(this.livw.getText()));
		Bathroom sdb = new Bathroom(Integer.parseInt(this.batl.getText()), Integer.parseInt(this.batw.getText()));

		/* génère le composant principal de la fenêtre principale
		 * passe les trois pièces en paramètre
		 */
		MainPanel container = new MainPanel(chambre, salon, sdb);
		
		// génère alors la fenêtre principale avec le composant créé en paramètre
		MainWindow mw = new MainWindow(container);
		
		// fermeture de la fenêtre d'accueil
		this.dispose();
	}
	
}