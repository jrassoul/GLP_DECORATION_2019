package decoration;

public class LivingRoom extends Room {

	public LivingRoom(int length, int width) {
		super(length, width);
	}
	
}