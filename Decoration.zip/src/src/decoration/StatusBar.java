package decoration;

import javax.swing.JLabel;
import javax.swing.JPanel;

// bar de staut, affiche des messages d'information lorsque un objet est sélectionné
public class StatusBar extends JPanel{
	
	private JLabel lblStatus1;
	private JLabel lblStatus2;
	
	public StatusBar() {
		this.lblStatus1 = new JLabel("Vous n'avez pas selectionné d'objet");
		this.lblStatus2 = new JLabel("");
		
		this.add(this.lblStatus1);
		this.add(this.lblStatus2);
	}

	public JLabel getLblStatus1() {
		return lblStatus1;
	}

	public JLabel getLblStatus2() {
		return lblStatus2;
	}

	public void setLblStatus1(JLabel lblStatus1) {
		this.lblStatus1 = lblStatus1;
	}

	public void setLblStatus2(JLabel lblStatus2) {
		this.lblStatus2 = lblStatus2;
	}
}
