package decoration;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.imageio.ImageIO;
import javax.swing.JPanel;

public class MainPanel extends JPanel{
	
	private static final long serialVersionUID = -2347023053379238138L;
	
	// trois pièces créées à l'issue de la fenêtre d'accueil
	private Bedroom chambre;
	private LivingRoom salon;
	private Bathroom sdb;
	
	// ratio utilisé pour la proportionnalité lors de l'affichage
	final int RATIO = 30;
	
	// ArrayList contenant les objets placés
	private ArrayList<DecorativeElement> elt = new ArrayList<DecorativeElement>();
	
	// ArrayList sauvegardant l'état des objets avant une action, permettant d'annuler cette action
	private ArrayList<DecorativeElement> undo = new ArrayList<DecorativeElement>();
	
	// ArrayList permettant de rétablir une action anulée
	private ArrayList<DecorativeElement> redo = new ArrayList<DecorativeElement>();
	
	// sauvegarde un objet prêt à être placé
	private DecorativeElement placeable = new DecorativeElement();
	
	// sauvegarde la position dans l'ArrayList de l'objet sélectionné
	private int selectedPosition;

	public MainPanel(Bedroom chambre, LivingRoom salon, Bathroom sdb) {
		this.chambre = chambre;
		this.salon = salon;
		this.sdb = sdb;
		
		// pas d'objet prêt à être placé à l'initialisation
		this.placeable = null;
		// pas d'objet sélectionné à l'initialisation
		this.selectedPosition = -1;
	}
	
	public Bedroom getChambre() {
		return chambre;
	}

	public LivingRoom getSalon() {
		return salon;
	}

	public Bathroom getSdb() {
		return sdb;
	}

	public ArrayList<DecorativeElement> getElt() {
		return elt;
	}

	public void setElt(ArrayList<DecorativeElement> elt) {
		this.elt = elt;
	}

	public ArrayList<DecorativeElement> getRedo() {
		return redo;
	}

	public void setRedo(ArrayList<DecorativeElement> redo) {
		this.redo = redo;
	}
	
	public ArrayList<DecorativeElement> getUndo() {
		return undo;
	}

	public void setUndo(ArrayList<DecorativeElement> undo) {
		this.undo = undo;
	}

	public DecorativeElement getPlaceable() {
		return placeable;
	}

	public void setPlaceable(DecorativeElement selected) {
		this.placeable = selected;
	}

	public int getSelectedPosition() {
		return selectedPosition;
	}

	public void setSelectedPosition(int selectedPosition) {
		this.selectedPosition = selectedPosition;
	}

	//gère l'affichage
	public void paintComponent(Graphics g) {
			
		
		//images pour le sol des pièces
		
		try {
			Image img= ImageIO.read(new File("src/img/solsalon.png"));
			g.drawImage(img, 25, 25, salon.getLength()*RATIO, salon.getWidth()*RATIO,this);
			Image img2= ImageIO.read(new File("src/img/solchambre.png"));
			g.drawImage(img2, 25+salon.getLength()*RATIO, 25, chambre.getLength()*RATIO, chambre.getWidth()*RATIO,this);
			Image img3= ImageIO.read(new File("src/img/solsdb.png"));
			g.drawImage(img3, 25+salon.getLength()*RATIO, 25+chambre.getWidth()*RATIO, sdb.getLength()*RATIO, sdb.getWidth()*RATIO,this);
		}catch(IOException e) {
			e.printStackTrace();
		}
		
		//contours noirs entre les pièces (murs)
		
		g.setColor(Color.black);
		g.drawRect(25, 25, salon.getLength()*RATIO, salon.getWidth()*RATIO);
		g.drawRect(25+salon.getLength()*RATIO, 25, chambre.getLength()*RATIO, chambre.getWidth()*RATIO);
		g.drawRect(25+salon.getLength()*RATIO, 25+chambre.getWidth()*RATIO, sdb.getLength()*RATIO, sdb.getWidth()*RATIO);
		
		
		//affichage des éléments placés
		
		for (int i = 0 ; i < this.elt.size(); i++) {
			g.drawImage(elt.get(i).current, (int)elt.get(i).getPositionx(), (int)elt.get(i).getPositiony(), (int)elt.get(i).getWidth(), (int)elt.get(i).getLength(), this);
		}
		
		//si un objet est sélectionné, un rectangle noir est tracé autour pour mieux le repérer
		
		if (this.getSelectedPosition()!=-1) {
			g.drawRect((int)elt.get(selectedPosition).getPositionx()-1, (int)elt.get(selectedPosition).getPositiony()-1, (int)elt.get(selectedPosition).getWidth()+1, (int)elt.get(selectedPosition).getLength()+1);
		}
		
		//étiquettes pour le nom des pièces
		
		g.drawString("Salon", 25+(salon.getLength())*15, 25+(salon.getWidth())*15);
		g.drawString("Chambre", 25+(salon.getLength())*30+(chambre.getLength())*15, 25+(chambre.getWidth())*15);
		g.drawString("Salle de bain", 25+(salon.getLength())*30+(sdb.getLength())*15, 25+(chambre.getWidth())*30+(sdb.getWidth())*15);
		
	}
}