package decoration;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import java.util.ArrayList;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JToolBar;

public class MainWindow extends JFrame {

	
	private static final long serialVersionUID = 5089241376730322885L;
	private JPanel container = new JPanel();
	
	// composant créé à l'issue de la fenêtre d'accueil
	private MainPanel center;
	private StatusBar statusBar;
	
	// sauvegarde la position dans l'ArrayList de l'objet sélectionné
	private int selectedPosition;
	
	public MainWindow(MainPanel center) {
		
		// pas d'objet sélectionné à l'initialisation
		this.selectedPosition = -1;
		
		this.statusBar = new StatusBar();
		
		this.center = center;
		this.setTitle("Appartement");
		// définit la taille de la fenêtre en fonction de la taille des pièces
		this.setSize((this.center.getSalon().getLength() + this.center.getChambre().getLength())*center.RATIO + 300, (this.center.getChambre().getWidth() + this.center.getSdb().getWidth())*center.RATIO + 150 );
		this.setLocationRelativeTo(null);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setResizable(true);
		
		this.setContentPane(this.container);
		
		this.setVisible(true);
		
		JPanel contentPane = (JPanel) this.getContentPane();
		contentPane.setLayout(new BorderLayout());
		
		// panneau contenant les boutons de style
		JPanel rightPanel = createRightPanel();

		// ajoute les différents éléments à la fenêtre
		// boutons de style à droite
		contentPane.add(rightPanel, BorderLayout.EAST);
		// composant principal au centre
		contentPane.add(this.center, BorderLayout.CENTER);
		// bar de statut, avec des informations sur un objet sélectionné
		contentPane.add(this.statusBar, BorderLayout.SOUTH);
		// boutons pour sélectionner l'objet à placer, à gauche
		contentPane.add(creatWestPanel(), BorderLayout.WEST);
		// boutons divers d'actions, en haut
		contentPane.add(creatToolBar(),BorderLayout.NORTH);
		
		this.addMouseListener(new MouseClickListener());
		
	}
	
	private JPanel createRightPanel() {
		
		// boutons de changement de style
		
		JPanel panel = new JPanel(new GridLayout(4,1));
		
		JButton style1 =new JButton("Style 1");
		style1.addActionListener(new Button1Listener());		
		panel.add(style1);
		
		JButton style2 =new JButton("Style 2");
		style2.addActionListener(new Button2Listener());		
		panel.add(style2);

		JButton style3 =new JButton("Style 3");
		style3.addActionListener(new Button3Listener());		
		panel.add(style3);
		
		return panel;
	}

	private JToolBar creatToolBar() {

		JToolBar toolbar = new JToolBar();
		
		// bouton permettant une décoration automatique
		JButton autodeco= new JButton("Décoration automatique");
		autodeco.addActionListener(new AutoDecorationListener());
		toolbar.add(autodeco);
		
		// supprime tous les objets placés
		JButton reatButton = new JButton("Réinitialisation");
		reatButton.addActionListener(new ReitButtonListener());
		toolbar.add(reatButton);
		
		// annule la dernière action effectuée
		JButton undo = new JButton("Annuler");
		undo.addActionListener(new UndoButtonListener());
		toolbar.add(undo);
		
		// si annulée, rétablit la dernière action
		JButton redo =  new JButton("Refaire");
		redo.addActionListener(new RedoButtonListener());
		toolbar.add(redo);
		
		// supprime un objet séletionné
		JButton suprObj = new JButton("Supprimer objet séléctionné");
		suprObj.addActionListener(new SuprObjListener());
		toolbar.add(suprObj);
			
		return toolbar;
	}
	
	private JPanel creatWestPanel() {
		
		JPanel westPanel = new JPanel();
		westPanel.setLayout(new BoxLayout(westPanel, BoxLayout.PAGE_AXIS));
		
		/* un bouton pour chaque type d'objet
		 * cliquer sur un bouton sélectionne l'objet correspondant, qui peut ensuite être placé par un simple clic dans l'appartement
		 */
		
		JButton baignoire = new JButton("Baignoire");
		baignoire.addActionListener(new BaignoireListener());
		westPanel.add(baignoire);
		JButton bureau = new JButton("Bureau");
		bureau.addActionListener(new BureauListener());
		westPanel.add(bureau);
		JButton canape = new JButton("Canapé");
		canape.addActionListener(new CanapeListener());
		westPanel.add(canape);
		JButton cuisiniere = new JButton("Cuisinière");
		cuisiniere.addActionListener(new CuisiniereListener());
		westPanel.add(cuisiniere);
		JButton fauteuil = new JButton ("Fauteuil");
		fauteuil.addActionListener(new FauteuilListener());
		westPanel.add(fauteuil);
		JButton lavabo = new JButton("Lavabo");
		lavabo.addActionListener(new LavaboListener());
		westPanel.add(lavabo);
		JButton lit = new JButton("Lit");
		lit.addActionListener(new LitListener());
		westPanel.add(lit);
		JButton plante = new JButton("Plante");
		plante.addActionListener(new PlanteListener());
		westPanel.add(plante);
		JButton tableAManger = new JButton("Table à manger");
		tableAManger.addActionListener(new TableAMangerListener());
		westPanel.add(tableAManger);
		JButton tableDeChevet = new JButton("Table de chevet");
		tableDeChevet.addActionListener(new TableDeChevetListener());
		westPanel.add(tableDeChevet);
		JButton petiteTable = new JButton("Petite Table");
		petiteTable.addActionListener(new PetiteTableListener());
		westPanel.add(petiteTable);
		JButton television = new JButton("Télevision");
		television.addActionListener(new TelevisionListener());
		westPanel.add(television);
		JButton toilette = new JButton("Toilette");
		toilette.addActionListener(new ToiletteListener());
		westPanel.add(toilette);
		
		return westPanel;
	}

	private class AutoDecorationListener implements ActionListener {
		
		// ArrayList de transition, permettant notemment le fonctionnement des boutons "Annuler" et "Refaire"
		private ArrayList<DecorativeElement> trans = new ArrayList<DecorativeElement>();
		
		public void actionPerformed(ActionEvent e) {
			
			// décoration automatique de l'appartment, les coordonnées des objets placés dépendent des dimensions des pièces
			trans.add(new Canapé(30, center.getSalon().getWidth()*center.RATIO/4));
			trans.add(new TableAManger(center.getSalon().getLength()*center.RATIO/4, center.getSalon().getWidth()*center.RATIO-70));
			trans.add(new Television(center.getSalon().getLength()*center.RATIO-30,center.getSalon().getWidth()*center.RATIO/2 - 60));
			trans.add(new Toilette(25+center.getSalon().getLength()*center.RATIO+center.getSdb().getWidth()*center.RATIO-65, 25+center.getChambre().getWidth()*center.RATIO));
			trans.add(new Baignoire(25+center.getSalon().getLength()*center.RATIO+center.getSdb().getWidth()*center.RATIO/2, 25+center.getChambre().getWidth()*center.RATIO+center.getSdb().getLength()*center.RATIO-76));
			trans.add(new Lavabo(25+center.getSalon().getLength()*center.RATIO+center.getSdb().getLength()*center.RATIO-160, 25+center.getChambre().getWidth()*center.RATIO));
			trans.add(new Lit(25+center.getSalon().getLength()*center.RATIO+center.getChambre().getLength()*center.RATIO/2 - 50, 26));
			trans.add(new Cuisiniere(25+center.getSalon().getLength()*center.RATIO-251,26));
			trans.add(new TableDeChevet(25+center.getSalon().getLength()*center.RATIO+center.getChambre().getLength()*center.RATIO/2 + 50, 26));
			trans.add(new TablePetite(90, center.getSalon().getWidth()*center.RATIO/4 + 30));
			trans.add(new Bureau(25+center.getSalon().getLength()*center.RATIO+center.getChambre().getLength()*center.RATIO-101, 25+center.getChambre().getWidth()*center.RATIO-81));
			trans.add(new Plante(25+center.getSalon().getLength()*center.RATIO+center.getChambre().getLength()*center.RATIO/2 - 101, 26));
			
			// prépare les éventuels annulation et/ou rétablissement de cette action
			center.setUndo(center.getElt());
			center.setRedo(null);

			center.setElt(this.trans);
			center.repaint();
		}
	}
	
	private class ReitButtonListener implements ActionListener {
		
		// ArrayList de transition, permettant notemment le fonctionnement des boutons "Annuler" et "Refaire"
		private ArrayList<DecorativeElement> trans = new ArrayList<DecorativeElement>();
		
		public void actionPerformed(ActionEvent e) {
			
			// prépare les éventuels annulation et/ou rétablissement de cette action
			center.setUndo(center.getElt());
			center.setRedo(null);
	
			center.setElt(this.trans);
			center.repaint();
		}
	}
	
	// annule la dernière action
	private class UndoButtonListener implements ActionListener {
		
		public void actionPerformed(ActionEvent e) {
			center.setRedo(center.getElt());
			center.setElt(center.getUndo());
			center.setUndo(null);
			
			center.repaint();
		}
	}
	
	// rétablit la dernière action si elle a été annulée
	private class RedoButtonListener implements ActionListener {
		
		public void actionPerformed(ActionEvent e) {
			center.setUndo(center.getElt());
			center.setElt(center.getRedo());
			center.setRedo(null);
			
			center.repaint();
		}
	}
	
	private class SuprObjListener implements ActionListener {
		
		// ArrayList de transition, permettant notemment le fonctionnement des boutons "Annuler" et "Refaire"
		private ArrayList<DecorativeElement> trans = new ArrayList<DecorativeElement>();

		public void actionPerformed(ActionEvent e) {
			trans = center.getElt();
			
			// vérifie qu'un objet est bien sélectionné
			if (selectedPosition!=-1) {
				
				trans.remove(selectedPosition);
				selectedPosition = -1;
				
				// prépare les éventuels annulation et/ou rétablissement de cette action
				center.setUndo(center.getElt());
				center.setRedo(null);
				
				center.setElt(this.trans);
				center.repaint();
			}
		}
		
	}
	
	private class Button1Listener implements ActionListener {
		
		// ArrayList de transition, permettant notemment le fonctionnement des boutons "Annuler" et "Refaire"
		private ArrayList<DecorativeElement> trans = new ArrayList<DecorativeElement>();
				
		public void actionPerformed(ActionEvent e) {
			trans = center.getElt();
			
			// si il n'y a pas d'objet sélectionné, changement du style de tous les objets placés
			if (selectedPosition==-1) {
				for (int i = 0 ; i < trans.size(); i++) {
					trans.get(i).setCurrent(trans.get(i).getStyle1());
				}
				
				// prépare les éventuels annulation et/ou rétablissement de cette action
				center.setUndo(center.getElt());
				center.setRedo(null);
				
				center.setElt(this.trans);
				center.repaint();
			}
			// si un objet est sélectionné, changement du style de cet objet uniquement
			else {
				trans.get(selectedPosition).setCurrent(trans.get(selectedPosition).getStyle1());
				
				// prépare les éventuels annulation et/ou rétablissement de cette action
				center.setUndo(center.getElt());
				center.setRedo(null);
				
				center.setElt(this.trans);
				center.repaint();
			}
		}
	}
	
	private class Button2Listener implements ActionListener {
		
		// ArrayList de transition, permettant notemment le fonctionnement des boutons "Annuler" et "Refaire"
		private ArrayList<DecorativeElement> trans = new ArrayList<DecorativeElement>();
				
		public void actionPerformed(ActionEvent e) {
			trans = center.getElt();
			
			// si il n'y a pas d'objet sélectionné, changement du style de tous les objets placés
			if (selectedPosition==-1) {
				for (int i = 0 ; i < trans.size(); i++) {
					trans.get(i).setCurrent(trans.get(i).getStyle2());
				}
				
				// prépare les éventuels annulation et/ou rétablissement de cette action
				center.setUndo(center.getElt());
				center.setRedo(null);
				
				center.setElt(this.trans);
				center.repaint();
			}
			// si un objet est sélectionné, changement du style de cet objet uniquement
			else {
				trans.get(selectedPosition).setCurrent(trans.get(selectedPosition).getStyle2());
				
				// prépare les éventuels annulation et/ou rétablissement de cette action
				center.setUndo(center.getElt());
				center.setRedo(null);
				
				center.setElt(this.trans);
				center.repaint();
			}
		}
	}
	
	private class Button3Listener implements ActionListener {
		
		// ArrayList de transition, permettant notemment le fonctionnement des boutons "Annuler" et "Refaire"
		private ArrayList<DecorativeElement> trans = new ArrayList<DecorativeElement>();
		
		public void actionPerformed(ActionEvent e) {
			trans = center.getElt();
			
			// si il n'y a pas d'objet sélectionné, changement du style de tous les objets placés
			if (selectedPosition==-1) {
				for (int i = 0 ; i < trans.size(); i++) {
					trans.get(i).setCurrent(trans.get(i).getStyle3());
				}
				
				// prépare les éventuels annulation et/ou rétablissement de cette action
				center.setUndo(center.getElt());
				center.setRedo(null);
				
				center.setElt(this.trans);
				center.repaint();
			}
			// si un objet est sélectionné, changement du style de cet objet uniquement
			else {
				trans.get(selectedPosition).setCurrent(trans.get(selectedPosition).getStyle3());
				
				// prépare les éventuels annulation et/ou rétablissement de cette action
				center.setUndo(center.getElt());
				center.setRedo(null);
				
				center.setElt(this.trans);
				center.repaint();
			}
		}
	}
	
	private class MouseClickListener implements MouseListener {
		
		// coordoonées du clic
		private int x;
		private int y;
		
		private DecorativeElement sel;
		
		// ArrayList de transition, permettant notemment le fonctionnement des boutons "Annuler" et "Refaire"
		private ArrayList<DecorativeElement> trans = new ArrayList<DecorativeElement>();
				
		public void mouseClicked(MouseEvent e) {
			
			// compteur d'objets situés là où le clic a été fait
			int c;
			
			// décalage lié à la présence des boutons au nord pour y, des boutons à gauche pour x
			x = e.getX() - 120;
			y = e.getY() - 50;
						
			trans = center.getElt();
			sel = center.getPlaceable();
			
			// si un objet est prêt à être placé, il est placé aux coordonnées x et y
			if (sel!=null) {
				center.setUndo(center.getElt());
				center.setRedo(null);
				
				sel.setPositionx(x);
				sel.setPositiony(y);
				trans.add(sel);
				
				// prépare les éventuels annulation et/ou rétablissement de cette action
				center.setUndo(center.getElt());
				center.setRedo(null);
				
				center.setElt(trans);
				center.setPlaceable(null);
				center.repaint();
			}
			// si aucun n'est prêt à être placé
			else {
				c = 0;
				// parcours l'ArrayList des objets déjà placés
				for (int i = 0 ; i < trans.size(); i++) {
					// dans le cas où un objet est présent dans la zone de clic, il est sélectionné
					if (((trans.get(i).getPositionx()<=x)&&(trans.get(i).getPositionx()+trans.get(i).getWidth())>=x)&&((trans.get(i).getPositiony()<=y)&&(trans.get(i).getPositiony()+trans.get(i).getLength()>=y))) {
						// affichage des informations sur l'objet sélectionné dans les messages au bas de la fenêtre
						statusBar.getLblStatus1().setText("Nom de l'objet sélectionné : " + trans.get(i).getName() + ".");
						statusBar.getLblStatus2().setText(trans.get(i).getNbstyle() + ".");
						c++;
						selectedPosition = i;
						center.setSelectedPosition(i);
						center.repaint();
					}
				}
				// si aucun objet est présent à l'endroit du clic, réinitialisation des messages en bas de la fenêtre
				if (c==0) {
					statusBar.getLblStatus1().setText("Vous n'avez pas sélectionné d'objet");
					statusBar.getLblStatus2().setText("");
					selectedPosition = -1;
					center.setSelectedPosition(-1);
					center.repaint();
				}
			}
		}

		public void mousePressed(MouseEvent e) {
			
		}

		public void mouseReleased(MouseEvent e) {
			
		}

		public void mouseEntered(MouseEvent e) {
			
		}

		public void mouseExited(MouseEvent e) {
			
		}
	}
	
	/* toutes les classes suivantes implémentes ActionListener
	 * elles correspondent chacune à un des boutons situés sur la gauche de la page
	 * chacune sélectionne l'objet correspondant, qui est alors prêt à être placé
	 */
	
	private class BaignoireListener implements ActionListener {
		
		public void actionPerformed(ActionEvent e) {
			center.setPlaceable(new Baignoire());
		}
	}
	
	private class BureauListener implements ActionListener {
		
		public void actionPerformed(ActionEvent e) {
			center.setPlaceable(new Bureau());
		}
	}
	
	private class CanapeListener implements ActionListener {
		
		public void actionPerformed(ActionEvent e) {
			center.setPlaceable(new Canapé());
		}
	}
	
	private class CuisiniereListener implements ActionListener {
		
		public void actionPerformed(ActionEvent e) {
			center.setPlaceable(new Cuisiniere());
		}
	}
	
	private class FauteuilListener implements ActionListener {
		
		public void actionPerformed(ActionEvent e) {
			center.setPlaceable(new Fauteuil());
		}
	}
	
	private class LavaboListener implements ActionListener {
		
		public void actionPerformed(ActionEvent e) {
			center.setPlaceable(new Lavabo());
		}
	}
	
	private class LitListener implements ActionListener {
		
		public void actionPerformed(ActionEvent e) {
			center.setPlaceable(new Lit());
		}
	}
	
	private class PlanteListener implements ActionListener {
		
		public void actionPerformed(ActionEvent e) {
			center.setPlaceable(new Plante());
		}
	}
	
	private class TableAMangerListener implements ActionListener {
		
		public void actionPerformed(ActionEvent e) {
			center.setPlaceable(new TableAManger());
		}
	}
	
	private class TableDeChevetListener implements ActionListener {
		
		public void actionPerformed(ActionEvent e) {
			center.setPlaceable(new TableDeChevet());
		}
	}
	
	private class PetiteTableListener implements ActionListener {
		
		public void actionPerformed(ActionEvent e) {
			center.setPlaceable(new TablePetite());
		}
	}
	
	private class TelevisionListener implements ActionListener {
		
		public void actionPerformed(ActionEvent e) {
			center.setPlaceable(new Television());
		}
	}
	
	private class ToiletteListener implements ActionListener {
		
		public void actionPerformed(ActionEvent e) {
			center.setPlaceable(new Toilette());
		}
	}

}