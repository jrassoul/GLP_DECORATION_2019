package decoration;

import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

//définit les dimensions, images de style et messages d'information de l'objet Petite table
public class TablePetite extends DecorativeElement{

	public TablePetite(float positionx, float positiony) {
		super(positionx, positiony);
		this.setName("Petite table");
		this.setNbstyle("2 styles disponibles");
		this.length = 80;
		this.width = 80;
		this.fstyle1 = new File("src/img/table_petite_style13.png");
		this.fstyle2 = new File("src/img/table_petite_style2.png");
		this.fstyle3 = new File("src/img/table_petite_style13.png");
		try {
			this.style1 = ImageIO.read(this.fstyle1);
			this.style2 = ImageIO.read(this.fstyle2);
			this.style3 = ImageIO.read(this.fstyle3);
		}catch(IOException e) {
			e.printStackTrace();
		}
		this.current = this.style1;
	}
	
	public TablePetite() {
		super();
		this.setName("Petite Table");
		this.setNbstyle("2 styles disponibles");
		this.length = 80;
		this.width = 80;
		this.fstyle1 = new File("src/img/table_petite_style13.png");
		this.fstyle2 = new File("src/img/table_petite_style2.png");
		this.fstyle3 = new File("src/img/table_petite_style13.png");
		try {
			this.style1 = ImageIO.read(this.fstyle1);
			this.style2 = ImageIO.read(this.fstyle2);
			this.style3 = ImageIO.read(this.fstyle3);
		}catch(IOException e) {
			e.printStackTrace();
		}
		this.current = this.style1;
	}

}
