package decoration;

public class Bedroom extends Room {

	public Bedroom(int length, int width) {
		super(length, width);
	}

}