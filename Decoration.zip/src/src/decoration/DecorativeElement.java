package decoration;

import java.awt.Image;
import java.io.File;

public class DecorativeElement {
	
	// longueur et largeur de l'objet
	protected float length;
	protected float width;
	
	// coordonnées de l'objet une fois placé
	private float positionx;
	private float positiony;

	// fichiers et images des trois styles possibles
	File fstyle1;
	File fstyle2;
	File fstyle3;
	
	Image style1;
	Image style2;
	Image style3;

	// image utilisée à l'affichage
	Image current;
	
	// informations affichées dans la StatusBar
	private String name;
	private String nbstyle;

	/* constructeur utilisé pour les objets placés avec la décoration automatique
	 * @see MainWindow.AutoDecorationListener
	 */
	
	public DecorativeElement(float positionx, float positiony) {
		this.positionx = positionx;
		this.positiony = positiony;
	}
	
	/* constructeur utilisé pour créer les objets quand ils ne sont pas encore placés
	* @see MainWindow.creatWestPanel()
	* ainsi que tous les ACtionListener associés
	*/
	public DecorativeElement() {
	}

	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}

	public String getNbstyle() {
		return nbstyle;
	}

	public void setNbstyle(String nbstyle) {
		this.nbstyle = nbstyle;
	}

	public float getLength() {
		return length;
	}

	public float getWidth() {
		return width;
	}

	public void setLength(float length) {
		this.length = length;
	}

	public void setWidth(float width) {
		this.width = width;
	}
	
	public float getPositionx() {
		return positionx;
	}

	public float getPositiony() {
		return positiony;
	}

	public void setPositionx(float positionx) {
		this.positionx = positionx;
	}

	public void setPositiony(float positiony) {
		this.positiony = positiony;
	}
	
	public Image getStyle1() {
		return style1;
	}

	public Image getStyle2() {
		return style2;
	}

	public Image getStyle3() {
		return style3;
	}

	public void setStyle1(Image style1) {
		this.style1 = style1;
	}

	public void setStyle2(Image style2) {
		this.style2 = style2;
	}

	public void setStyle3(Image style3) {
		this.style3 = style3;
	}

	public void setCurrent(Image img) {
		this.current = img;
	}
}