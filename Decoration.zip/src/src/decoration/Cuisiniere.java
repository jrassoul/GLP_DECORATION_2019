package decoration;

import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

//définit les dimensions, images de style et messages d'information de l'objet Cuisinière
public class Cuisiniere extends DecorativeElement{

	public Cuisiniere(float positionx, float positiony) {
		super(positionx, positiony);
		this.setName("Cuisinière");
		this.setNbstyle("3 styles disponibles");
		this.length = 67;
		this.width = 250;
		this.fstyle1 = new File("src/img/cuisiniere_style1.png");
		this.fstyle2 = new File("src/img/cuisiniere_style2.png");
		this.fstyle3 = new File("src/img/cuisiniere_style3.png");
		try {
			this.style1 = ImageIO.read(this.fstyle1);
			this.style2 = ImageIO.read(this.fstyle2);
			this.style3 = ImageIO.read(this.fstyle3);
		}catch(IOException e) {
			e.printStackTrace();
		}
		this.current = this.style1;
	}
	
	public Cuisiniere() {
		super();
		this.setName("Cuisinière");
		this.setNbstyle("3 styles disponibles");
		this.length = 67;
		this.width = 250;
		this.fstyle1 = new File("src/img/cuisiniere_style1.png");
		this.fstyle2 = new File("src/img/cuisiniere_style2.png");
		this.fstyle3 = new File("src/img/cuisiniere_style3.png");
		try {
			this.style1 = ImageIO.read(this.fstyle1);
			this.style2 = ImageIO.read(this.fstyle2);
			this.style3 = ImageIO.read(this.fstyle3);
		}catch(IOException e) {
			e.printStackTrace();
		}
		this.current = this.style1;
	}

}
