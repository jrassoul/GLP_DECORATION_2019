package decoration;

import javax.swing.UIManager;
import javax.swing.plaf.nimbus.NimbusLookAndFeel;

// contient la méthode main, lance l'éxecution du programme
public class Main {
	
	public static void main(String[] args) throws Exception{
		UIManager.setLookAndFeel(new NimbusLookAndFeel());
		
		IntroWindow fen = new IntroWindow();	
	}
}