package decoration;

public class Bathroom extends Room {

	public Bathroom(int length, int width) {
		super(length, width);
	}

}